"""C-problem causal benchmark study, with explicit non-official conventions."""

import argparse
import datetime as dt
import hashlib
import json
import time
from pathlib import Path

import numpy as np
import openpyxl
from scipy.optimize import linprog
from scipy.sparse import lil_matrix


ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
DATA = ROOT / "C\u9898" / "\u9644\u4ef6"
ETA = 0.9
LOW, HIGH, POWER = 1200.0, 10800.0, 5000.0 / 6
DATES = [dt.date(2025, 1, 1) + dt.timedelta(days=i) for i in range(365)]


def read_rows(name, sheet=0):
    wb = openpyxl.load_workbook(DATA / name, read_only=True, data_only=True)
    rows = list(wb.worksheets[sheet].values)
    wb.close()
    return rows


def load_data():
    daily_rows = read_rows("\u9644\u4ef61.xlsx")
    daily = np.asarray([r[1:] for r in daily_rows[1:]], dtype=float)
    lr = read_rows("\u9644\u4ef62.xlsx")
    pr = read_rows("\u9644\u4ef62.xlsx", 1)
    er = read_rows("\u9644\u4ef64.xlsx")
    for source in [lr, pr, er]:
        assert [r[0].date() for r in source[1:]] == DATES
    load, pv, price = [
        np.asarray([r[1:] for r in source[1:]], dtype=float)
        for source in [lr, pr, er]
    ]
    fr = read_rows("\u9644\u4ef63.xlsx")[1:]
    current_date = None
    for i, row in enumerate(fr):
        if row[0]:
            current_date = dt.datetime.strptime(str(row[0]), "%Y-%m-%d").date()
        assert current_date == DATES[i // 4]
        assert str(row[1]) == f"{6 * (i % 4)}:00"
    forecast = np.asarray([r[2:] for r in fr], dtype=float).reshape(365, 4, 24)
    for array in [daily, load, pv, price, forecast]:
        assert np.isfinite(array).all()
    return daily, load, pv, price, forecast


def solve_plan(net, price, initial, target=6000.0, base=None, refund=False):
    """All variables are AC kWh except stored energy; surplus can be discarded."""
    n = len(net)
    # New purchase, charge, discharge, surplus, E[0:n+1], optional cancellation.
    size = 5 * n + 1 + (n if refund and base is not None else 0)
    objective = np.zeros(size)
    objective[:n] = price * (1.5 if base is not None else 1.0)
    bounds = (
        [(0, None)] * n
        + [(0, POWER)] * (2 * n)
        + [(0, None)] * n
        + [(LOW, HIGH)] * (n + 1)
    )
    bounds[4 * n] = (initial, initial)
    if target is not None:
        bounds[5 * n] = (target, target)
    matrix = lil_matrix((2 * n, size))
    rhs = np.zeros(2 * n)
    if base is None:
        base = np.zeros(n)
        cancellation = False
    else:
        cancellation = refund
    if cancellation:
        bounds += [(0, float(v)) for v in base]
        objective[5 * n + 1 :] = -0.5 * price
    for t in range(n):
        matrix[t, t] = 1
        matrix[t, n + t] = -1
        matrix[t, 2 * n + t] = 1
        matrix[t, 3 * n + t] = -1
        if cancellation:
            matrix[t, 5 * n + 1 + t] = -1
        rhs[t] = net[t] - base[t]
        matrix[n + t, 4 * n + t + 1] = 1
        matrix[n + t, 4 * n + t] = -1
        matrix[n + t, n + t] = -ETA
        matrix[n + t, 2 * n + t] = 1 / ETA
    result = linprog(
        objective, A_eq=matrix.tocsr(), b_eq=rhs, bounds=bounds, method="highs"
    )
    if not result.success:
        raise RuntimeError(result.message)
    x = result.x
    # Remove loss-making charge/discharge cycles without changing stored energy.
    c = x[n : 2 * n].copy()
    d = x[2 * n : 3 * n].copy()
    cycle = np.minimum(c, d / ETA**2)
    c -= cycle
    d -= ETA**2 * cycle
    waste = x[3 * n : 4 * n] + (1 - ETA**2) * cycle
    down = x[5 * n + 1 :] if cancellation else np.zeros(n)
    q = base + x[:n] - down
    assert np.max(np.abs(q + d - c - waste - net)) < 1e-6
    assert np.max(np.abs(np.diff(x[4 * n : 5 * n + 1]) - ETA * c + d / ETA)) < 1e-6
    return {
        "q": np.maximum(q, 0),
        "up": np.maximum(x[:n], 0),
        "down": np.maximum(down, 0),
        "charge": c,
        "discharge": d,
        "energy": x[4 * n : 5 * n + 1],
        "surplus": waste,
        "objective": result.fun,
        "residual": float(np.max(np.abs(result.eqlin.residual))),
        "cycle_removal_kwh": float(cycle.sum()),
    }


def causal_forecasts(load, pv, price, forecast):
    n = len(load)
    load_hat = np.zeros((n, 4, 144))
    pv_hat = np.zeros((n, 4, 144))
    historical_pv = np.zeros_like(load)
    price_hat = np.zeros_like(price)
    for day in range(7, n):
        prior = load[max(0, day - 7) : day]
        weekly = load[np.arange(day - 7, max(-1, day - 29), -7)]
        initial_load = 0.5 * prior.mean(axis=0) + 0.5 * weekly.mean(axis=0)
        historical_pv[day] = pv[max(0, day - 7) : day].mean(axis=0)
        price_hat[day] = price[max(0, day - 7) : day].mean(axis=0)
        for update, hour in enumerate([0, 6, 12, 18]):
            start = hour * 6
            load_hat[day, update] = initial_load
            if start:
                error = (load[day, max(0, start - 12) : start] -
                         initial_load[max(0, start - 12) : start]).mean()
                bias = np.clip(error, -0.2 * initial_load.mean(), 0.2 * initial_load.mean())
                load_hat[day, update, start:] = np.maximum(
                    initial_load[start:] + 0.5 * bias, 0
                )
            boundary = pv[day, start - 1] if start else pv[day - 1, -1]
            times = np.arange(hour, hour + 25)
            values = np.r_[boundary, forecast[day, update]]
            pv_hat[day, update, start:] = np.interp(
                np.arange(start + 1, 145) / 6, times, values
            )
    return load_hat, pv_hat, historical_pv, price_hat


def net_prediction(day, update, issued, quantile, raw, hats, frozen_pv=False):
    load, pv, _, _ = raw
    lh, ph, hpv, _ = hats
    start = update * 36
    pv_update = 0 if frozen_pv else update
    pred = lh[day, update] - (ph[day, pv_update] if issued else hpv[day])
    if quantile is not None:
        past = np.arange(max(7, day - 28), day)
        old_prediction = lh[past, update] - (
            ph[past, pv_update] if issued else hpv[past]
        )
        residual = load[past] - pv[past] - old_prediction
        margin = np.maximum(np.quantile(residual[:, start:], quantile, axis=0), 0)
        pred = pred.copy()
        pred[start:] += margin
    return pred[start:] / 6


def backtest(config, daily, raw, hats):
    load, pv, price, _ = raw
    state = 6000.0
    keys = ["plan", "purchase", "up", "down", "emergency", "charge", "discharge", "surplus", "cost"]
    arrays = {key: np.zeros((334, 144)) for key in keys}
    arrays["soc"] = np.zeros((334, 145))
    actual_prices = price[31:] if config["variable"] else np.tile(daily[:, 0], (334, 1))
    solver_calls, max_residual, cycle_total = 0, 0.0, 0.0
    for day in range(31, 365):
        index = day - 31
        arrays["soc"][index, 0] = state
        pp = hats[3][day] if config["variable"] else daily[:, 0]
        pred = net_prediction(day, 0, config["issued"], config["quantile"], raw, hats)
        if config.get("no_storage"):
            plan = np.maximum(pred, 0)
        else:
            solution = solve_plan(pred, pp, state)
            plan = solution["q"].copy()
            max_residual = max(max_residual, solution["residual"])
            cycle_total += solution["cycle_removal_kwh"]
            solver_calls += 1
        arrays["plan"][index] = plan
        q = plan.copy()
        for t in range(144):
            if t in config["updates"]:
                update = t // 36
                pred = net_prediction(
                    day, update, True, config["quantile"], raw, hats,
                    frozen_pv=config.get("frozen_pv", False),
                )
                solution = solve_plan(
                    pred, pp[t:], state, base=q[t:], refund=config.get("refund", False)
                )
                q[t:] = solution["q"]
                arrays["up"][index, t:] += solution["up"]
                arrays["down"][index, t:] += solution["down"]
                solver_calls += 1
                max_residual = max(max_residual, solution["residual"])
                cycle_total += solution["cycle_removal_kwh"]
            available = q[t] + (pv[day, t] - load[day, t]) / 6
            if available >= 0:
                c = 0 if config.get("no_storage") else min(
                    available, POWER, max(0, HIGH - state) / ETA
                )
                d = e = 0.0
                waste = available - c
            else:
                c = waste = 0.0
                d = 0 if config.get("no_storage") else min(
                    -available, POWER, max(0, state - LOW) * ETA
                )
                e = -available - d
            state += ETA * c - d / ETA
            for key, value in [
                ("purchase", q[t]), ("emergency", e), ("charge", c),
                ("discharge", d), ("surplus", waste),
            ]:
                arrays[key][index, t] = value
            arrays["soc"][index, t + 1] = state
        down_rate = -0.5 if config.get("refund") else 0.5
        arrays["cost"][index] = actual_prices[index] * (
            plan + 1.5 * arrays["up"][index] + down_rate * arrays["down"][index]
            + 5 * arrays["emergency"][index]
        )
    balance = (
        arrays["purchase"] + pv[31:] / 6 + arrays["discharge"] + arrays["emergency"]
        - load[31:] / 6 - arrays["charge"] - arrays["surplus"]
    )
    state_error = np.diff(arrays["soc"], axis=1) - ETA * arrays["charge"] + arrays["discharge"] / ETA
    daily_cost = arrays["cost"].sum(axis=1)
    cost_parts = {
        "planned": float((actual_prices * arrays["plan"]).sum()),
        "upward": float((1.5 * actual_prices * arrays["up"]).sum()),
        "downward_net": float((down_rate * actual_prices * arrays["down"]).sum()),
        "emergency": float((5 * actual_prices * arrays["emergency"]).sum()),
    }
    summary = {
        "config": config,
        "total_cost": float(daily_cost.sum()),
        "cost_parts": cost_parts,
        "planned_kwh": float(arrays["plan"].sum()),
        "adjusted_kwh": float(arrays["purchase"].sum()),
        "up_kwh": float(arrays["up"].sum()),
        "down_kwh": float(arrays["down"].sum()),
        "emergency_kwh": float(arrays["emergency"].sum()),
        "emergency_slots": int((arrays["emergency"] > 1e-7).sum()),
        "emergency_days": int((arrays["emergency"].sum(axis=1) > 1e-7).sum()),
        "emergency_load_pct": float(100 * arrays["emergency"].sum() / (load[31:].sum() / 6)),
        "surplus_kwh": float(arrays["surplus"].sum()),
        "initial_soc": 6000.0,
        "final_soc": state,
        "min_soc": float(arrays["soc"].min()),
        "max_soc": float(arrays["soc"].max()),
        "max_charge_kw": float(arrays["charge"].max() * 6),
        "max_discharge_kw": float(arrays["discharge"].max() * 6),
        "max_balance_residual": float(np.max(np.abs(balance))),
        "max_soc_residual": float(np.max(np.abs(state_error))),
        "max_crossday_soc_jump": float(np.max(np.abs(arrays["soc"][1:, 0] - arrays["soc"][:-1, -1]))),
        "simultaneous_slots": int(((arrays["charge"] > 1e-7) & (arrays["discharge"] > 1e-7)).sum()),
        "p95_daily_cost": float(np.quantile(daily_cost, 0.95)),
        "cvar95_daily_cost": float(np.sort(daily_cost)[-int(np.ceil(0.05 * 334)):].mean()),
        "solver_calls": solver_calls,
        "max_solver_residual": max_residual,
        "planned_cycle_removed_kwh": cycle_total,
    }
    assert summary["max_balance_residual"] < 1e-6
    assert summary["max_soc_residual"] < 1e-6
    assert summary["max_crossday_soc_jump"] < 1e-6
    assert summary["min_soc"] >= LOW - 1e-6 and summary["max_soc"] <= HIGH + 1e-6
    assert summary["simultaneous_slots"] == 0
    assert abs(sum(cost_parts.values()) - summary["total_cost"]) < 1e-5
    assert np.max(np.abs(arrays["purchase"] - arrays["plan"] - arrays["up"] + arrays["down"])) < 1e-6
    return arrays, summary


def interval(t):
    return f"{t // 6:02d}:{t % 6 * 10:02d}-{(t + 1) // 6:02d}:{(t + 1) % 6 * 10:02d}"


def emergency_events(arrays):
    output = []
    for i in range(334):
        active = arrays["emergency"][i] > 1e-7
        t = 0
        while t < 144:
            if not active[t]:
                t += 1
                continue
            end = t + 1
            while end < 144 and active[end]:
                end += 1
            output.append([
                DATES[i + 31].isoformat(),
                f"{t // 6:02d}:{t % 6 * 10:02d}-{end // 6:02d}:{end % 6 * 10:02d}",
                float(arrays["emergency"][i, t:end].sum()),
            ])
            t = end
    return output


def write_workbook(name, arrays, summary):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "readme"
    ws.append(["Conditional research output; not an unmodified official template"])
    ws.append(["Intervals use previous-ten-minute interpretation; January battery idle at 6000 kWh"])
    ws.append(["Configuration", json.dumps(summary["config"])])
    ws.append(["Main settlement: original plan paid; upward 1.5p; emergency 5p; no refund"])
    for key in ["plan", "purchase", "up", "down"]:
        ws = wb.create_sheet(key)
        ws.append(["date", *[interval(t) for t in range(144)]])
        for i, row in enumerate(arrays[key]):
            ws.append([DATES[i + 31].isoformat(), *[float(v) for v in row]])
        ws.freeze_panes = "B2"
    ws = wb.create_sheet("storage_4h")
    ws.append(["date", "period", "charge_AC_kWh", "discharge_AC_kWh", "soc_start", "soc_end"])
    for i in range(334):
        for block in range(6):
            lo, hi = block * 24, (block + 1) * 24
            ws.append([
                DATES[i + 31].isoformat(), f"{block * 4}:00-{(block + 1) * 4}:00",
                float(arrays["charge"][i, lo:hi].sum()),
                float(arrays["discharge"][i, lo:hi].sum()),
                float(arrays["soc"][i, lo]), float(arrays["soc"][i, hi]),
            ])
    ws = wb.create_sheet("emergency_events")
    ws.append(["date", "period", "emergency_kWh"])
    for row in emergency_events(arrays):
        ws.append(row)
    ws = wb.create_sheet("daily")
    ws.append(["date", "cost_yuan", "planned_kWh", "emergency_kWh", "soc_start", "soc_end"])
    for i in range(334):
        ws.append([
            DATES[i + 31].isoformat(), float(arrays["cost"][i].sum()),
            float(arrays["plan"][i].sum()), float(arrays["emergency"][i].sum()),
            float(arrays["soc"][i, 0]), float(arrays["soc"][i, -1]),
        ])
    wb.save(OUT / (name + ".xlsx"))


def paired_bootstrap(a, b):
    delta = a - b
    rng = np.random.default_rng(20260910)
    n = len(delta)
    values = []
    for _ in range(2000):
        starts = rng.integers(0, n, size=int(np.ceil(n / 7)))
        indices = ((starts[:, None] + np.arange(7)) % n).ravel()[:n]
        values.append(delta[indices].mean() * n)
    return {
        "difference_a_minus_b_yuan": float(delta.sum()),
        "circular_7day_block_bootstrap_95pct": np.quantile(values, [0.025, 0.975]).tolist(),
        "warning": "Descriptive resampling under block-stationarity approximation; one year only",
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--skip-workbooks", action="store_true")
    args = parser.parse_args()
    start = time.perf_counter()
    daily, load, pv, price, forecast = load_data()
    raw = (load, pv, price, forecast)
    hats = causal_forecasts(*raw)
    configs = [
        dict(name="q2_no_storage", issued=False, quantile=0.8, updates=[], variable=False, no_storage=True),
        dict(name="q2_mean", issued=False, quantile=None, updates=[], variable=False),
        dict(name="q2_q80", issued=False, quantile=0.8, updates=[], variable=False),
        dict(name="q3_00", issued=True, quantile=0.8, updates=[], variable=False),
        dict(name="q3_06", issued=True, quantile=0.8, updates=[36], variable=False),
        dict(name="q3_0612", issued=True, quantile=0.8, updates=[36, 72], variable=False),
        dict(name="q3_all", issued=True, quantile=0.8, updates=[36, 72, 108], variable=False),
        dict(name="q3_frozen_pv", issued=True, quantile=0.8, updates=[36, 72, 108], variable=False, frozen_pv=True),
        dict(name="q4_q2", issued=False, quantile=0.8, updates=[], variable=True),
        dict(name="q4_q3", issued=True, quantile=0.8, updates=[36, 72, 108], variable=True),
        dict(name="q3_refund", issued=True, quantile=0.8, updates=[36, 72, 108], variable=False, refund=True),
    ]
    summaries, runs = {}, {}
    for config in configs:
        arrays, summary = backtest(config, daily, raw, hats)
        name = config["name"]
        summaries[name] = summary
        runs[name] = arrays
        np.savez_compressed(OUT / (name + ".npz"), **arrays)
        print(name, round(summary["total_cost"], 2), round(summary["emergency_kwh"], 2), flush=True)
    q1 = solve_plan((daily[:, 1] - daily[:, 2]) / 6, daily[:, 0], 6000)
    assert q1["cycle_removal_kwh"] < 1e-6
    np.savez_compressed(OUT / "q1.npz", **{k: v for k, v in q1.items() if isinstance(v, np.ndarray)})
    q1_summary = {
        "cost": float(daily[:, 0] @ q1["q"]),
        "purchase_kwh": float(q1["q"].sum()),
        "no_storage_cost": float(daily[:, 0] @ np.maximum((daily[:, 1] - daily[:, 2]) / 6, 0)),
        "selected_slots": {interval(t): float(q1["q"][t]) for t in [60, 72, 84, 96, 108, 120]},
        "storage_4h": [
            [f"{i * 4}:00-{(i + 1) * 4}:00", float(q1["charge"][i*24:(i+1)*24].sum()),
             float(q1["discharge"][i*24:(i+1)*24].sum())]
            for i in range(6)
        ],
    }
    selected_dates = ["2025-03-20", "2025-06-21", "2025-09-23", "2025-12-21"]
    date_lookup = {d.isoformat(): i - 31 for i, d in enumerate(DATES) if i >= 31}
    selected = {}
    for name in ["q2_q80", "q3_all", "q4_q2", "q4_q3"]:
        arrays = runs[name]
        entries = []
        for date in selected_dates:
            i = date_lookup[date]
            entries.append({
                "date": date,
                "cost": float(arrays["cost"][i].sum()),
                "plan_kwh": float(arrays["plan"][i].sum()),
                "adjusted_kwh": float(arrays["purchase"][i].sum()),
                "emergency_kwh": float(arrays["emergency"][i].sum()),
                "soc_initial": float(arrays["soc"][i, 0]),
                "soc_final": float(arrays["soc"][i, -1]),
                "selected_slots": [
                    [interval(t), float(arrays["plan"][i, t]), float(arrays["purchase"][i, t])]
                    for t in [60, 72, 84, 96, 108, 120]
                ],
                "storage_4h": [
                    [f"{j*4}:00-{(j+1)*4}:00", float(arrays["charge"][i,j*24:(j+1)*24].sum()),
                     float(arrays["discharge"][i,j*24:(j+1)*24].sum())]
                    for j in range(6)
                ],
                "emergency_events": [r[1:] for r in emergency_events(arrays) if r[0] == date],
            })
        selected[name] = entries
        if not args.skip_workbooks:
            write_workbook(name, arrays, summaries[name])
    # The perfect-information reference is conditioned on the policy's daily SOC boundaries.
    for name in ["q2_q80", "q3_all", "q4_q2", "q4_q3"]:
        reference = 0.0
        for i, day in enumerate(range(31, 365)):
            pp = price[day] if summaries[name]["config"]["variable"] else daily[:, 0]
            sol = solve_plan(
                (load[day] - pv[day]) / 6, pp,
                float(runs[name]["soc"][i, 0]), float(runs[name]["soc"][i, -1]),
            )
            reference += float(pp @ sol["q"])
        assert reference <= summaries[name]["total_cost"] + 1e-5
        summaries[name]["boundary_matched_perfect_info_cost"] = reference
        summaries[name]["premium_over_reference_pct"] = 100 * (summaries[name]["total_cost"] / reference - 1)
    comparisons = {}
    for a, b in [
        ("q2_mean", "q2_q80"), ("q2_no_storage", "q2_q80"),
        ("q3_00", "q3_06"), ("q3_06", "q3_0612"), ("q3_0612", "q3_all"),
        ("q2_q80", "q3_all"), ("q4_q2", "q4_q3"),
        ("q3_frozen_pv", "q3_all"),
    ]:
        comparisons[f"{a}_minus_{b}"] = paired_bootstrap(
            runs[a]["cost"].sum(axis=1), runs[b]["cost"].sum(axis=1)
        )
    hashes = {}
    for path in sorted(DATA.glob("*.xlsx")):
        hashes[path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
    output = {
        "assumptions": {
            "interval": "row endpoint mapped to preceding 10 minutes",
            "jan_warmup": "battery deliberately idle at 6000 kWh; January actual data used only after observed",
            "main_settlement": "no plan refund; marginal upward 1.5p; emergency 5p; upward only",
            "variable_price": "previous-seven-day per-slot average forecast; actual price only for settlement",
            "daily_target": "planned terminal SOC=6000; actual SOC carried forward without resetting",
            "controller": "surplus charges / deficit discharges within physical limits, emergency for remaining deficit",
            "prediction": "load half previous7 mean + half previous4 same weekdays; PV previous7 or issued interpolation",
            "reserve": "nonnegative 0.8 quantile of preceding28 causal residuals, fixed heuristic not globally optimized",
        },
        "data_hashes": hashes,
        "q1": q1_summary,
        "runs": summaries,
        "selected_dates": selected,
        "comparisons": comparisons,
        "elapsed_s": time.perf_counter() - start,
    }
    (OUT / "study_results.json").write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    print("Completed in", round(output["elapsed_s"], 2), "seconds", flush=True)


if __name__ == "__main__":
    main()
