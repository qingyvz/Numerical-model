"""Generate measured charts, tables, and an auditable report data package."""

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from run_study import OUT, DATES, load_data, causal_forecasts


plt.rcParams.update({
    "font.family": ["Arial Unicode MS", "Arial"],
    "font.size": 10,
    "axes.unicode_minus": False,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.titleweight": "bold",
    "figure.facecolor": "white",
    "savefig.facecolor": "white",
})
COLORS = ["#157568", "#287CB2", "#BB5D37", "#A64469", "#7A7E85"]
LABELS = {
    "q2_no_storage": "Q2 无储能",
    "q2_mean": "Q2 无备用",
    "q2_q80": "Q2 分位备用",
    "q3_00": "Q3 仅0时",
    "q3_06": "Q3 加6时",
    "q3_0612": "Q3 加6/12时",
    "q3_all": "Q3 全部更新",
    "q3_frozen_pv": "Q3 冻结光伏",
    "q4_q2": "Q4-2 波动电价",
    "q4_q3": "Q4-3 波动电价",
    "q3_refund": "Q3 退款敏感性",
}


def table(headers, rows):
    def fmt(value):
        if isinstance(value, (float, np.floating)):
            return f"{value:,.4f}"
        return str(value).replace("|", "/").replace("\n", " ")
    return "\n".join([
        "| " + " | ".join(map(fmt, headers)) + " |",
        "|" + "|".join("---" for _ in headers) + "|",
        *["| " + " | ".join(map(fmt, row)) + " |" for row in rows],
    ])


def save_chart(fig, filename):
    fig.savefig(OUT / filename, dpi=190, bbox_inches="tight")
    plt.close(fig)


def main():
    result = json.loads((OUT / "study_results.json").read_text())
    daily, load, pv, prices, forecast = load_data()
    hours = np.arange(1, 145) / 6
    q1 = np.load(OUT / "q1.npz")
    fig, axes = plt.subplots(2, 1, figsize=(8.2, 5.0), sharex=True)
    axes[0].plot(hours, daily[:, 1], color=COLORS[1], label="负载")
    axes[0].plot(hours, daily[:, 2], color=COLORS[0], label="光伏预测")
    axes[0].plot(hours, q1["q"] * 6, color=COLORS[2], label="计划购电功率")
    axes[0].set_ylabel("功率 / kW")
    axes[0].legend(ncol=3, frameon=False)
    axes[0].set_title("第1问：确定性计划与储能状态")
    axes[1].plot(np.arange(145) / 6, q1["energy"], color=COLORS[0], label="SOC")
    axes[1].axhline(1200, ls=":", color=COLORS[4])
    axes[1].axhline(10800, ls=":", color=COLORS[4])
    axes[1].set_ylabel("电量 / kWh")
    ax2 = axes[1].twinx()
    ax2.plot(hours, daily[:, 0], color=COLORS[2], alpha=0.65)
    ax2.set_ylabel("电价 / 元·kWh⁻¹", color=COLORS[2])
    axes[1].set_xlabel("时间 / h")
    axes[1].set_xticks(np.arange(0, 25, 4))
    fig.tight_layout()
    save_chart(fig, "fig1_q1.png")

    names = ["q2_mean", "q2_q80", "q3_00", "q3_all", "q3_frozen_pv", "q4_q2", "q4_q3"]
    fig, ax = plt.subplots(figsize=(8.2, 4.4))
    bottom = np.zeros(len(names))
    for key, label, color in [
        ("planned", "日前计划费", COLORS[1]),
        ("upward", "上调费", COLORS[0]),
        ("emergency", "应急费", COLORS[2]),
    ]:
        values = np.array([result["runs"][n]["cost_parts"][key] / 1e4 for n in names])
        ax.bar(np.arange(len(names)), values, bottom=bottom, label=label, color=color, width=0.65)
        bottom += values
    ax.set_xticks(np.arange(len(names)), [LABELS[n] for n in names], rotation=20, ha="right")
    ax.set_ylabel("2—12月费用 / 万元")
    ax.legend(frameon=False, ncol=3)
    ax.set_title("费用分解：普通计划费不能代替总费用")
    fig.tight_layout()
    save_chart(fig, "fig2_costs.png")

    months = np.array([d.month for d in DATES[31:]])
    fig, axes = plt.subplots(2, 1, figsize=(8.2, 5.3), sharex=True)
    for i, name in enumerate(["q2_q80", "q3_all", "q3_frozen_pv"]):
        arrays = np.load(OUT / f"{name}.npz")
        mcost = [arrays["cost"][months == m].sum() / 1e4 for m in range(2, 13)]
        memergency = [arrays["emergency"][months == m].sum() / 1000 for m in range(2, 13)]
        axes[0].plot(range(2, 13), mcost, marker="o", label=LABELS[name], color=COLORS[i])
        axes[1].plot(range(2, 13), memergency, marker="o", color=COLORS[i])
    axes[0].set_ylabel("月费用 / 万元")
    axes[0].legend(ncol=3, frameon=False)
    axes[0].set_title("月度表现：同时检查成本与应急购电")
    axes[1].set_ylabel("应急电量 / MWh")
    axes[1].set_xlabel("月份")
    axes[1].set_xticks(range(2, 13))
    fig.tight_layout()
    save_chart(fig, "fig3_monthly.png")

    fig, ax = plt.subplots(figsize=(8.2, 4.1))
    for i, name in enumerate(["q3_00", "q3_06", "q3_0612", "q3_all", "q3_frozen_pv"]):
        s = result["runs"][name]
        ax.scatter(s["emergency_kwh"] / 1000, s["total_cost"] / 1e4, s=65, color=COLORS[i])
        ax.annotate(LABELS[name], (s["emergency_kwh"]/1000, s["total_cost"]/1e4),
                    xytext=(5, 7 if i % 2 == 0 else -14), textcoords="offset points", fontsize=9)
    ax.set_xlabel("应急购电量 / MWh")
    ax.set_ylabel("总费用 / 万元")
    ax.set_title("预报更新策略的成本—风险权衡")
    ax.margins(0.20)
    fig.tight_layout()
    save_chart(fig, "fig4_tradeoff.png")

    fig, axes = plt.subplots(2, 2, figsize=(8.2, 5.5), sharex=True, sharey=True)
    for ax, date in zip(axes.ravel(), ["2025-03-20", "2025-06-21", "2025-09-23", "2025-12-21"]):
        i = [d.isoformat() for d in DATES[31:]].index(date)
        for j, name in enumerate(["q2_q80", "q3_all"]):
            arrays = np.load(OUT / f"{name}.npz")
            ax.plot(np.arange(145)/6, arrays["soc"][i], label=LABELS[name], color=COLORS[j])
        ax.set_title(date)
        ax.set_xticks([0, 6, 12, 18, 24])
        ax.set_ylim(0, 12000)
        ax.axhline(1200, color="#BBBBBB", ls=":")
        ax.axhline(10800, color="#BBBBBB", ls=":")
    axes[0, 0].legend(frameon=False, fontsize=9)
    axes[1, 0].set_xlabel("时间 / h")
    axes[1, 1].set_xlabel("时间 / h")
    axes[0, 0].set_ylabel("SOC / kWh")
    axes[1, 0].set_ylabel("SOC / kWh")
    fig.tight_layout()
    save_chart(fig, "fig5_selected_soc.png")

    blocks = {}
    blocks["RESULTS_ALL"] = table(
        ["实验", "总费/万元", "应急/MWh", "应急日数", "末端SOC/kWh"],
        [[LABELS[n], s["total_cost"]/1e4, s["emergency_kwh"]/1000, s["emergency_days"], s["final_soc"]]
         for n, s in result["runs"].items()],
    )
    blocks["COST_PARTS"] = table(
        ["策略", "计划费/万元", "上调费/万元", "应急费/万元", "总费/万元"],
        [[LABELS[n], *[result["runs"][n]["cost_parts"][k]/1e4 for k in ["planned", "upward", "emergency"]],
          result["runs"][n]["total_cost"]/1e4] for n in ["q2_mean", "q2_q80", "q3_all", "q3_frozen_pv", "q4_q2", "q4_q3"]],
    )
    blocks["Q1_SELECTED"] = table(["时段", "计划购电量/kWh"], result["q1"]["selected_slots"].items())
    blocks["Q1_STORAGE"] = table(["时段", "充电量/kWh", "放电量/kWh"], result["q1"]["storage_4h"])
    blocks["REFERENCE"] = table(
        ["策略", "策略费用/万元", "边界匹配参考/万元", "费用溢价/%"],
        [[LABELS[n], s["total_cost"]/1e4, s["boundary_matched_perfect_info_cost"]/1e4, s["premium_over_reference_pct"]]
         for n, s in result["runs"].items() if "boundary_matched_perfect_info_cost" in s],
    )
    blocks["SELECTED_SUMMARY"] = table(
        ["策略", "日期", "总费/元", "应急/kWh", "日初SOC", "日末SOC"],
        [[LABELS[n], e["date"], e["cost"], e["emergency_kwh"], e["soc_initial"], e["soc_final"]]
         for n, entries in result["selected_dates"].items() for e in entries],
    )
    blocks["BOOTSTRAP"] = table(
        ["差额（前者减后者）", "总差额/万元", "重采样区间/万元"],
        [[key.replace("_minus_", " − "), v["difference_a_minus_b_yuan"]/1e4,
          " ~ ".join(f"{x/1e4:.4f}" for x in v["circular_7day_block_bootstrap_95pct"])]
         for key,v in result["comparisons"].items()],
    )
    appendix = []
    for n, entries in result["selected_dates"].items():
        appendix.append(f"### {LABELS[n]}：指定日期详表")
        for entry in entries:
            appendix.append(f"**{entry['date']}**")
            appendix.append(
                f"全天日前计划 {entry['plan_kwh']:,.4f} kWh，调整后合同 {entry['adjusted_kwh']:,.4f} kWh，"
                f"总费用 {entry['cost']:,.4f} 元。"
            )
            appendix.append(table(
                ["购电时段", "日前/kWh", "调整后/kWh", "储能时段", "充电/kWh", "放电/kWh"],
                [[*slot, *storage] for slot,storage in zip(entry["selected_slots"], entry["storage_4h"])],
            ))
            events = entry["emergency_events"]
            appendix.append("应急购电：" + ("无。" if not events else "；".join(
                f"{period}：{amount:,.4f} kWh" for period, amount in events
            ) + "。"))
    blocks["APPENDIX_SELECTED"] = "\n\n".join(appendix)
    diagnostic = {}
    hats = causal_forecasts(load, pv, prices, forecast)
    for k, values in [("load", load), ("pv", pv), ("net", load-pv), ("price", prices)]:
        diagnostic[k] = {
            "min": float(values.min()), "median": float(np.median(values)),
            "max": float(values.max()), "mean": float(values.mean()),
        }
    predmetrics = []
    for label, prediction, truth in [
        ("负载日前基准", hats[0][31:,0], load[31:]),
        ("光伏历史7日", hats[2][31:], pv[31:]),
        ("光伏0时发布插值", hats[1][31:,0], pv[31:]),
        ("波动电价历史7日", hats[3][31:], prices[31:]),
    ]:
        error = prediction-truth
        predmetrics.append([
            label, float(np.mean(np.abs(error))), float(np.sqrt(np.mean(error**2))),
            float(100*np.abs(error).sum()/np.abs(truth).sum()),
        ])
    blocks["FORECAST_METRICS"] = table(["对象", "MAE", "RMSE", "WAPE/%"], predmetrics)
    blocks["DATA_STATS"] = table(
        ["变量", "最小值", "中位数", "最大值", "均值"],
        [[label, *[diagnostic[k][x] for x in ["min","median","max","mean"]]]
         for k,label in [("load","负载/kW"),("pv","光伏/kW"),("net","净负荷/kW"),("price","电价/(元/kWh)")]],
    )
    blocks["TAIL_STATS"] = table(
        ["策略", "P95日费/元", "最贵17日均费/元", "应急占负载/%", "总溢出/MWh"],
        [[LABELS[n], s["p95_daily_cost"],s["cvar95_daily_cost"],s["emergency_load_pct"],s["surplus_kwh"]/1000]
         for n,s in result["runs"].items() if n in ["q2_q80","q3_all","q3_frozen_pv","q4_q3"]],
    )
    (OUT / "report_blocks.json").write_text(json.dumps(blocks,ensure_ascii=False,indent=2),encoding="utf-8")
    (OUT / "data_diagnostics.json").write_text(json.dumps(diagnostic,indent=2),encoding="utf-8")
    print("Prepared charts and report tables")


if __name__ == "__main__":
    main()
