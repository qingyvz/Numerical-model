"""Create a typeset Word research report with editable native math."""

import json
import re
import zipfile
from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor
from latex2mathml.converter import convert as latex_to_mathml
from mathml2omml import convert as mathml_to_omml
from markdown_it import MarkdownIt


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OUTPUT = ROOT / "C\u9898\u5b8c\u6574\u5206\u6790\u62a5\u544a.docx"
MATH_NS = "http://schemas.openxmlformats.org/officeDocument/2006/math"


def set_font(style, latin="Times New Roman", east="Songti SC", size=10.5):
    style.font.name = latin
    style.font.size = Pt(size)
    style.element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), east)


def field(paragraph, instruction):
    run = paragraph.add_run()
    begin = OxmlElement("w:fldChar")
    begin.set(qn("w:fldCharType"), "begin")
    text = OxmlElement("w:instrText")
    text.set(qn("xml:space"), "preserve")
    text.text = instruction
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    run._r.extend([begin, text, end])


def add_inline(paragraph, children, small=False):
    bold = italic = False
    for token in children or []:
        if token.type == "strong_open":
            bold = True
        elif token.type == "strong_close":
            bold = False
        elif token.type == "em_open":
            italic = True
        elif token.type == "em_close":
            italic = False
        elif token.type in ("text", "code_inline"):
            run = paragraph.add_run(token.content)
            run.bold, run.italic = bold, italic
            if token.type == "code_inline":
                run.font.name = "Consolas"
                run.font.size = Pt(8.5 if small else 9)
            elif small:
                run.font.size = Pt(8.5)
        elif token.type in ("softbreak", "hardbreak"):
            paragraph.add_run().add_break()
        elif token.type in ("link_open", "link_close"):
            pass
        else:
            raise ValueError(f"Unsupported inline content: {token.type}")


def add_equation(doc, text, index):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.keep_together = True
    p.paragraph_format.space_before = Pt(5)
    p.paragraph_format.space_after = Pt(7)
    omml = mathml_to_omml(latex_to_mathml(" ".join(text.strip().splitlines())))
    omml = omml.replace("<m:oMath>", f'<m:oMath xmlns:m="{MATH_NS}">', 1)
    element = parse_xml(omml)
    p._p.append(element)
    run = p.add_run(f"    ({index})")
    run.font.size = Pt(9)
    return p


def set_table_style(table, columns):
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    width = 16.8
    for column in table.columns:
        column.width = Cm(width / columns)
    table.style = "Table Grid"
    for ri, row in enumerate(table.rows):
        props = row._tr.get_or_add_trPr()
        no_split = OxmlElement("w:cantSplit")
        props.append(no_split)
        if ri == 0:
            props.append(OxmlElement("w:tblHeader"))
        for cell in row.cells:
            cell.width = Cm(width / columns)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            tcpr = cell._tc.get_or_add_tcPr()
            margins = OxmlElement("w:tcMar")
            for name in ["top", "left", "bottom", "right"]:
                m = OxmlElement(f"w:{name}")
                m.set(qn("w:w"), "65")
                m.set(qn("w:type"), "dxa")
                margins.append(m)
            tcpr.append(margins)
            if ri == 0:
                shade = OxmlElement("w:shd")
                shade.set(qn("w:fill"), "E8F0F0")
                tcpr.append(shade)
            for p in cell.paragraphs:
                p.paragraph_format.space_after = Pt(2)
                p.paragraph_format.space_before = Pt(2)
                p.paragraph_format.line_spacing = 1.05
                p.paragraph_format.keep_with_next = ri == 0
                for run in p.runs:
                    run.font.size = Pt(8.5)
                    if ri == 0:
                        run.bold = True


def add_table(doc, tokens):
    rows, row, cell = [], None, None
    for token in tokens:
        if token.type == "tr_open":
            row = []
        elif token.type in ("th_open", "td_open"):
            cell = []
        elif token.type == "inline":
            cell.extend(token.children or [])
        elif token.type in ("th_close", "td_close"):
            row.append(cell)
        elif token.type == "tr_close":
            rows.append(row)
    columns = len(rows[0])
    table = doc.add_table(rows=0, cols=columns)
    for row in rows:
        assert len(row) == columns
        cells = table.add_row().cells
        for i, content in enumerate(row):
            add_inline(cells[i].paragraphs[0], content, small=True)
    set_table_style(table, columns)
    spacer = doc.add_paragraph()
    spacer.paragraph_format.space_after = Pt(1)
    spacer.paragraph_format.space_before = Pt(0)
    spacer.paragraph_format.line_spacing = 0.5


def configure(doc):
    section = doc.sections[0]
    section.page_width, section.page_height = Cm(21), Cm(29.7)
    section.top_margin, section.bottom_margin = Cm(2.1), Cm(2.0)
    section.left_margin, section.right_margin = Cm(2.1), Cm(2.1)
    section.header_distance, section.footer_distance = Cm(0.9), Cm(1.0)
    section.different_first_page_header_footer = True
    normal = doc.styles["Normal"]
    set_font(normal)
    normal.paragraph_format.line_spacing = 1.2
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.widow_control = True
    for name, size in [("Title", 27), ("Subtitle", 16), ("Heading 1", 17), ("Heading 2", 12)]:
        style = doc.styles[name]
        set_font(style, "Arial", "Heiti SC", size)
        style.font.color.rgb = RGBColor.from_string("175D59")
        style.paragraph_format.keep_with_next = True
        style.paragraph_format.space_before = Pt(12)
        style.paragraph_format.space_after = Pt(8)
    doc.styles["Heading 1"].paragraph_format.page_break_before = True
    set_font(doc.styles["Caption"], size=9)
    header = section.header.paragraphs[0]
    header.add_run("C题 · 微网与外部电网电力调控策略")
    header.style = doc.styles["Caption"]
    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer.add_run("研究报告  |  ")
    field(footer, " PAGE ")
    footer.add_run(" / ")
    field(footer, " NUMPAGES ")
    props = doc.core_properties
    props.title = "C题完整分析报告：微网与外部电网电力调控策略"
    props.subject = "四问建模、十一组全年回测、指定日期结果与验证"
    props.author = "AI-assisted technical analysis"
    props.keywords = "微网;储能;线性规划;滚动优化;时序回测"


def build(markdown):
    doc = Document()
    configure(doc)
    tokens = MarkdownIt("commonmark").enable("table").parse(markdown)
    i, equations, tables, images = 0, 0, 0, 0
    list_stack = []
    item_prefix = None
    while i < len(tokens):
        token = tokens[i]
        if token.type == "heading_open":
            text_token = tokens[i + 1]
            if token.tag == "h1":
                p = doc.add_paragraph(style="Title")
                p.paragraph_format.space_before = Pt(65)
            elif text_token.content == "完整建模分析与全年回测报告":
                p = doc.add_paragraph(style="Subtitle")
            else:
                p = doc.add_paragraph(style=f"Heading {int(token.tag[1:]) - 1}")
            add_inline(p, text_token.children)
            i += 3
            continue
        if token.type == "paragraph_open":
            inline = tokens[i + 1]
            image_tokens = [c for c in inline.children or [] if c.type == "image"]
            if image_tokens:
                for image in image_tokens:
                    p = doc.add_paragraph()
                    p.paragraph_format.keep_with_next = True
                    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    p.add_run().add_picture(str(HERE / image.attrGet("src")), width=Cm(16.4))
                    caption = doc.add_paragraph(image.content, style="Caption")
                    caption.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    images += 1
            else:
                p = doc.add_paragraph()
                if item_prefix is not None:
                    p.add_run(item_prefix)
                    p.paragraph_format.left_indent = Cm(0.35)
                    p.paragraph_format.first_line_indent = Cm(-0.35)
                    item_prefix = None
                add_inline(p, inline.children)
                if len(inline.content) < 25 and inline.content.startswith("**2025-"):
                    p.paragraph_format.keep_with_next = True
            i += 3
            continue
        if token.type == "table_open":
            end = i + 1
            while tokens[end].type != "table_close":
                end += 1
            add_table(doc, tokens[i : end + 1])
            tables += 1
            i = end + 1
            continue
        if token.type == "fence":
            if token.info.strip() == "math":
                equations += 1
                add_equation(doc, token.content, equations)
            else:
                p = doc.add_paragraph()
                p.paragraph_format.line_spacing = 1.0
                run = p.add_run(token.content.rstrip())
                run.font.name = "Consolas"
                run.font.size = Pt(8)
            i += 1
            continue
        if token.type in ("ordered_list_open", "bullet_list_open"):
            list_stack.append(1 if token.type == "ordered_list_open" else None)
        elif token.type in ("ordered_list_close", "bullet_list_close"):
            list_stack.pop()
        elif token.type == "list_item_open":
            value = list_stack[-1]
            item_prefix = "- " if value is None else f"{value}. "
            if value is not None:
                list_stack[-1] += 1
        elif token.type != "list_item_close":
            raise ValueError(f"Unsupported block token: {token.type}")
        i += 1
    doc.save(OUTPUT)
    with zipfile.ZipFile(OUTPUT) as archive:
        assert archive.testzip() is None
        xml = archive.read("word/document.xml").decode()
        assert xml.count("<m:oMath>") == equations or xml.count("<m:oMath ") == equations
        assert "{{" not in xml
    reopened = Document(OUTPUT)
    assert len(reopened.tables) == tables
    return {"output": str(OUTPUT), "tables": tables, "equations": equations, "images": images, "bytes": OUTPUT.stat().st_size}


def main():
    template = (HERE / "report_template.md").read_text(encoding="utf-8")
    blocks = json.loads((HERE / "report_blocks.json").read_text(encoding="utf-8"))
    for name, value in blocks.items():
        template = template.replace("{{" + name + "}}", value)
    if re.search(r"\{\{[A-Z_]+\}\}", template):
        raise ValueError("Unfilled report placeholders")
    (HERE / "C题完整分析报告.md").write_text(template, encoding="utf-8")
    summary = build(template)
    (HERE / "word_build.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
