"""Independent checks on stored traces and a future-data perturbation audit."""

import json
from pathlib import Path

import numpy as np

from run_study import causal_forecasts, load_data, net_prediction, OUT


def main():
    result = json.loads((OUT / "study_results.json").read_text())
    daily, load, pv, price, forecast = load_data()
    checks = {}
    for name, summary in result["runs"].items():
        with np.load(OUT / f"{name}.npz") as a:
            pp = price[31:] if summary["config"]["variable"] else daily[:, 0][None, :]
            refund = summary["config"].get("refund", False)
            costs = pp * (a["plan"] + 1.5 * a["up"] + (-0.5 if refund else 0.5) * a["down"] + 5 * a["emergency"])
            balance = a["purchase"] + a["emergency"] + a["discharge"] - a["charge"] - a["surplus"] + (pv[31:] - load[31:]) / 6
            err = np.diff(a["soc"], axis=1) - 0.9 * a["charge"] + a["discharge"] / 0.9
            assert abs(costs.sum() - summary["total_cost"]) < 1e-5
            assert np.max(np.abs(costs - a["cost"])) < 1e-7
            assert np.max(np.abs(balance)) < 1e-6
            assert np.max(np.abs(err)) < 1e-6
            assert np.min(a["soc"]) >= 1200 - 1e-6
            assert np.max(a["soc"]) <= 10800 + 1e-6
            assert np.max(a["charge"]) <= 5000 / 6 + 1e-6
            assert np.max(a["discharge"]) <= 5000 / 6 + 1e-6
            assert np.max(np.minimum(a["charge"], a["discharge"])) < 1e-7
            assert np.max(np.abs(a["soc"][1:, 0] - a["soc"][:-1, -1])) < 1e-7
            assert abs(a["soc"][0, 0] - 6000) < 1e-7
            checks[name] = {
                "balance_error_kwh": float(np.max(np.abs(balance))),
                "soc_error_kwh": float(np.max(np.abs(err))),
                "cost_recomputed": float(costs.sum()),
                "passed": True,
            }
    raw = (load, pv, price, forecast)
    original = causal_forecasts(*raw)
    altered = tuple(a.copy() for a in raw)
    day = 200
    for a in altered:
        a[day + 1:] *= 1.7
    altered[0][day, 72:] *= 1.4
    altered[1][day, 72:] *= 0.4
    altered[2][day, :] *= 2.5
    altered[3][day, 3, :] *= 1.9
    changed = causal_forecasts(*altered)
    diffs = []
    for update in [0, 1, 2]:
        for issued in ([False, True] if update == 0 else [True]):
            a = net_prediction(day, update, issued, 0.8, raw, original)
            b = net_prediction(day, update, issued, 0.8, altered, changed)
            diffs.append(float(np.max(np.abs(a - b))))
    assert max(diffs) == 0
    assert np.array_equal(original[3][day], changed[3][day])
    report = {
        "stored_trace_checks": checks,
        "future_perturbation": {
            "day_index": day,
            "date": "2025-07-20",
            "changed": "future days; today actual load/PV from noon; all today settlement prices; 18h forecast",
            "unchanged": "00h/06h/12h net predictions and day-ahead price forecast",
            "max_prediction_change": max(diffs),
            "passed": True,
            "scope": "Representative dependency audit; not a proof of all possible timing conditions",
        },
    }
    (OUT / "validation.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
