# C题计算与验证材料

本目录支持工作区根目录中的 `C题完整分析报告.docx`。报告覆盖四问分析、11组逐时回测和四个指定日期的详细结果。

## 口径

- 输入文件：原始 `C题/附件/附件1.xlsx` 至 `附件4.xlsx`；保持只读。
- 时间：将00:10记录解释为00:00—00:10区间的代表功率；原模板存在时段标签差异，提交前必须确认。
- 储能：交流侧功率限制5000 kW，单程效率各90%，SOC范围1200—10800 kWh。
- 1月：储能主动闲置，维持6000 kWh，历史数据按观察顺序进入预测；2—12月实际SOC连续传递。
- 主结算：原计划费用不退，上调增量1.5倍，紧急购电5倍；不进行无经济价值的下调。
- 退款实验：退原计划取消部分费用，再收50%违约金；单独重算，不与主制度混用。
- 波动价格：历史7日同时段均价预测，真实未来价格仅用于结算。
- 本次为条件性研究结果，不是经官方口径确认的最终提交材料。

## 复现

在工作区根目录运行：

```bash
uv run --with numpy==2.5.3 --with scipy==1.18.1 --with openpyxl==3.1.5 python analysis/c_study/run_study.py
uv run --with numpy==2.5.3 --with scipy==1.18.1 --with openpyxl==3.1.5 python analysis/c_study/validate_study.py
uv run --with numpy --with scipy --with openpyxl --with matplotlib python analysis/c_study/prepare_report_data.py
uv run --with python-docx --with markdown-it-py --with latex2mathml --with mathml2omml python analysis/c_study/build_word.py
```

`study_results.json` 含原始输入SHA-256和全部实验统计。主计算和独立检查均通过。

## 输出说明

- 四份xlsx是研究数据工作簿，采用自然日标签；未覆盖、未修改原官方模板。
- 工作表plan为日前计划，purchase为修订后合同量，up/down为累计修订，应急单独记录。
- storage_4h给出最终实际执行量；emergency_events合并相邻非零应急时段。
- NPZ保存全精度十分钟轨迹，使用NumPy读取；成本统计在舍入前计算。
- 原始工作区保留全部11组NPZ；精简交付压缩包保留问题1及四个主方案的NPZ，其他实验可由代码复现。
- Word含37张表、23组原生可编辑公式、5幅计算图。其文件结构、重新读取和系统预览检查通过。
- 本机Word自动导出与应用状态检查超时，未完成逐页Word渲染验证；没有生成成功的PDF预览版。

本报告使用AI辅助完成，最终参赛内容需要队员独立审查、修改和验证，并按官方规定如实声明。
